# Bone & Banner Arena

Mod Fabric per una battaglia automatica tra **Skeleton e Pillager**, con comandante, squadre, AI comportamentale e abilità **Ultimo Respiro**. Codice e commenti in italiano. Non richiede servizi AI, chiavi API o connessioni esterne durante il gioco.

## Versioni esatte

| Componente | Versione del progetto |
| --- | --- |
| Minecraft Java Edition | **1.21.1** |
| JDK per compilare e avviare | **21** |
| Fabric Loader | **0.16.14** |
| Fabric API | **0.116.6+1.21.1** |
| Yarn | **1.21.1+build.3** |
| Fabric Loom | **1.8.13** |
| Gradle Wrapper | **8.10.2**, incluso e con checksum |

Questa mod è destinata esclusivamente a Minecraft **1.21.1**. Per un'installazione che usa Minecraft 26.3, crea un profilo Fabric 1.21.1 con una directory di gioco separata e un mondo nuovo; non aprire il mondo 26.3 nella versione precedente.

La logica gira sul server, incluso il server integrato del giocatore singolo. Si usano entità, attributi, particelle e suoni vanilla; non sono necessarie texture personalizzate o registrazioni di nuove entità.

## Aprire nell'IDE

1. Installa un **JDK 21**, ad esempio [Eclipse Temurin](https://adoptium.net/temurin/releases/?version=21).
2. Apri questa cartella in IntelliJ IDEA come progetto Gradle, selezionando `build.gradle` o la cartella stessa.
3. Imposta **Project SDK = 21** e **Gradle JVM = 21**. Usa il wrapper incluso.
4. Attendi il download delle dipendenze. Internet serve alla prima compilazione e per eventuali dipendenze non ancora presenti nella cache.
5. Avvia il task Gradle **runClient**. In alternativa usa i comandi riportati sotto.

Non serve installare Gradle globalmente. VS Code con le estensioni Java e Gradle può importare lo stesso progetto.

### Windows PowerShell

```powershell
java -version
.\gradlew.bat build
.\gradlew.bat runClient
```

`java -version` deve indicare 21. Se il computer usa ancora Java 8, imposta `JAVA_HOME` alla cartella del JDK 21 nell'IDE o nel terminale corrente:

```powershell
$env:JAVA_HOME = 'C:\percorso\del\jdk-21'
.\gradlew.bat build
```

### Linux e macOS

```sh
chmod +x gradlew
./gradlew build
./gradlew runClient
```

## Prima battaglia

Nel client di sviluppo crea un mondo **Creativa**, preferibilmente **Superpiatto**, con i comandi abilitati. Scegli difficoltà Normale. Raggiungi uno spazio aperto, poi usa:

```mcfunction
/difficulty normal
/arena build
/arena start
```

`build` crea un campo **41 × 41** cinque blocchi sopra i tuoi piedi, ti porta al centro e imposta la posizione dell'arena. Il pavimento ha due colori, pareti di vetro, illuminazione e quattro piccole coperture. Il comando controlla prima l'intero volume: se trova un blocco, interrompe la costruzione senza sostituirlo.

Parte un ingresso di cinque secondi, con dialoghi, particelle e suono di battaglia. Entrano **6 Skeleton contro 6 Pillager**, comandante incluso. Puoi osservare in volo o passare a spettatore:

```mcfunction
/gamemode spectator
```

Le fazioni combattono senza comandi aggiuntivi. La barra superiore mostra fase e superstiti. Al termine, i vincitori restano per otto secondi e la sessione si ripulisce; il campo rimane pronto per `/arena start`.

## Comandi

Tutti richiedono permessi operatore di livello 2, oppure i comandi abilitati in giocatore singolo.

| Comando | Effetto |
| --- | --- |
| `/arena` oppure `/arena help` | Mostra l'aiuto. |
| `/arena build [raggio]` | Costruisce un campo in un volume vuoto sopra il giocatore e ne imposta il centro. Raggio 16–48, default 20. |
| `/arena set [raggio]` | Imposta il centro ai piedi del giocatore per un'arena già costruita. Non cambia blocchi. |
| `/arena start` | Avvia 6 contro 6 nell'arena configurata. |
| `/arena start 8 6` | Avvia 8 Skeleton contro 6 Pillager; ciascuna fazione può avere 1–12 unità. |
| `/arena status` | Mostra fase, superstiti, centro, raggio e ultimo risultato. |
| `/arena reset` | Ferma la battaglia e rimuove combattenti, frecce, squadre temporanee e barra. Conserva centro e blocchi. |

La posizione del centro usa l'altezza dei **piedi** dei mob: il pavimento deve essere il blocco immediatamente sotto. L'area supportata è quadrata, piana, con almeno tre blocchi liberi in altezza; i punti d'ingresso vengono controllati all'avvio. Corridoi larghi almeno due blocchi permettono al comandante di passare.

È attiva una sola arena per server. Per cambiare centro, dimensione o campo durante una battaglia usa prima `reset`. Da console sono disponibili `start`, `status` e `reset`; `set` e `build` richiedono un giocatore.

## Comportamenti implementati

### Skeleton

- Due squadre che cercano i fianchi in direzioni opposte.
- Distanza di tiro maggiore nella schermaglia, avanzata durante l'assalto.
- Bersagli valutati per distanza, linea di vista, salute, continuità e fuoco della squadra.
- Bonus di priorità contro il comandante Pillager.
- Ritirata quando feriti o troppo vicini al bersaglio; la ritirata dovuta alla ferita dura al massimo tre secondi.
- Rinvio del tiro se un alleato attraversa la linea di fuoco.

### Pillager e comandante

- Due squadre, con convergenza sul bersaglio scelto dal primo compagno di ciascuna squadra.
- Priorità agli Skeleton che minacciano il comandante.
- **Comandante Ferronero**: scala **1,45**, **64 punti vita**, armatura 6, resistenza al contraccolpo e frecce più forti.
- Il comandante si tiene più distante quando scende sotto il 40% della vita.
- Ogni sei secondi il comandante protegge brevemente gli alleati entro dieci blocchi con Resistenza I.
- Alla sua morte i Pillager abbandonano il fuoco coordinato di squadra, avanzano più direttamente e ottengono un breve aumento di velocità.

Il danno a distanza è impostato sui proiettili: aumentare soltanto l'attributo di attacco corpo a corpo o applicare Strength non renderebbe più potenti le frecce.

### Fasi

```text
INATTIVA → INGRESSO (5 s) → SCHERMAGLIA
                                ↓
                 ASSALTO (dopo 30 s o metà perdite)
                                ↓
       ULTIMO RESPIRO (se si attiva l'abilità del superstite)
                                ↓
            VITTORIA PILLAGER / SKELETON / PAREGGIO
                                ↓
                CELEBRAZIONE (8 s) → INATTIVA
```

L'abilità può attivarsi anche durante la schermaglia. Una vittoria può chiudere qualsiasi fase di combattimento. Dopo tre minuti di combattimento senza un vincitore, la sessione termina in pareggio, evitando blocchi permanenti su arene non percorribili.

### Ultimo Respiro

L'**ultimo Skeleton vivo** può attivarla **una sola volta per battaglia**:

1. Quando raggiunge il 25% della vita, oppure quando un colpo lo ucciderebbe, annulla la morte e torna all'85% della vita massima.
2. Per **200 tick / 10 secondi a 20 TPS** riceve Velocità II, Resistenza II, contorno luminoso, cura di 1,5 punti vita al secondo, tiro più rapido e frecce potenziate.
3. Suono del totem, particelle e dialogo annunciano l'attivazione.
4. Alla scadenza cessano cura e potenziamenti. La vita recuperata rimane, ma la resurrezione non può riattivarsi.

La cura è esplicita nel codice: l'effetto Regeneration vanilla non cura gli scheletri. Il comando amministrativo `/kill` rimane intenzionalmente efficace e non attiva la resurrezione.

### Fine battaglia

- **Pillager vincono**: annuncio, suono, contorno luminoso, salti e particelle celebrative dei superstiti.
- **Skeleton vincono**: annuncio e suono dedicato.
- **Pareggio**: entrambi eliminati o tempo massimo raggiunto.
- Frecce e bersagli vengono cancellati immediatamente al risultato, prima della pulizia finale.

## Installare il JAR in Minecraft

Il pacchetto contiene il JAR già compilato in **`dist/bone-banner-arena-1.0.0.jar`**. Per ricompilarlo dai sorgenti, esegui `build`: il risultato viene scritto in:

```text
build/libs/bone-banner-arena-1.0.0.jar
```

Il file `-sources.jar` contiene il codice sorgente e non va installato come mod.

1. Crea un profilo **Minecraft 1.21.1** con [Fabric Loader](https://fabricmc.net/use/installer/), versione 0.16.14 o successiva compatibile.
2. Copia il JAR della mod e **Fabric API 0.116.6+1.21.1** nella cartella `mods` di quel profilo.
3. Avvia il profilo e crea il mondo di prova.

Su un server dedicato, installa entrambi nella cartella `mods` del server Fabric 1.21.1. La mod è progettata per funzionare lato server anche con client 1.21.1 privi della mod, perché usa il protocollo e i contenuti vanilla. In giocatore singolo serve invece installarla nel client che ospita il server integrato.

Per avviare un server di sviluppo:

```powershell
.\gradlew.bat runServer
```

Al primo avvio Minecraft può chiedere di leggere e accettare la propria EULA nel file `run/eula.txt`; la scelta spetta all'utente. I GameTest usano un ambiente di test separato.

## Test automatici

```powershell
.\gradlew.bat build
.\gradlew.bat runGametest
```

`build` compila, esegue cinque test JUnit delle regole e produce il JAR rimappato. `runGametest` avvia un server Minecraft di test e verifica in uno scenario sequenziale:

- comando di avvio, conteggio dei combattenti, dimensione e salute del comandante;
- scelta dei bersagli nemici;
- blocco del fuoco amico e protezione dei mob esterni;
- morte normale di uno scheletro non finale;
- annullamento di un colpo letale, scadenza e uso singolo di Ultimo Respiro;
- vittoria Pillager, vittoria Skeleton e pareggio;
- pulizia automatica, reset ripetuto, eliminazione delle frecce e delle entità orfane;
- conservazione dei mob esterni.
- combattimento reale fra due squadre, con danni prodotti dai goal e dalle frecce senza interventi del test.

Le classi e le risorse di test non vengono incluse nel JAR distribuito. Il rapporto JUnit è in `build/reports/tests/test/index.html`; il rapporto GameTest è in `build/gametest-results.xml`.

Consulta anche [TEST_MANUALI.md](TEST_MANUALI.md) per la prova visiva e [VERIFICA.md](VERIFICA.md) per lo stato dei controlli eseguiti durante la preparazione.

## Struttura del codice

```text
src/main/java/it/bonebanner/
├── ArenaMod.java                 Registrazione eventi e gestione per server
├── arena/
│   ├── ArenaManager.java         Sessione, fasi, squadre, vittorie, pulizia
│   ├── ArenaBuilder.java         Campo dimostrativo
│   ├── ArenaRules.java           Durate e punteggio dei bersagli
│   ├── LastBreath.java           Stato dell'abilità, con uso singolo
│   ├── Fighter.java              Stato individuale del combattente
│   ├── Faction.java              Le due fazioni
│   └── Phase.java                Stati della battaglia
├── ai/ArenaCombatGoal.java       Movimento, ritirata, tiro, navigazione
├── command/ArenaCommands.java    Comandi /arena
└── mixin/MobEntityAccessor.java  Accesso ai selettori dei goal
src/main/resources/              Metadati Fabric e configurazione Mixin
src/test/                        JUnit e GameTest, separati dalla mod
```

Per il bilanciamento, modifica le durate in `ArenaRules`, salute e scala in `ArenaManager.spawn`, ritmi di tiro e danno delle frecce in `ArenaCombatGoal`. Non esiste ancora un file JSON di configurazione: queste impostazioni richiedono ricompilazione.

## Confini della prima versione

- Le sessioni e il centro configurato non vengono salvati: dopo un riavvio imposta nuovamente il centro. I blocchi del campo rimangono nel mondo.
- Le entità marcate dell'arena vengono rimosse al riavvio quando i loro chunk sono caricati. I nomi scoreboard `bba_s_XXXXXX` e `bba_p_XXXXXX` sono riservati alla mod.
- Il reset conserva i blocchi e non costituisce un ripristino del terreno. Eventuali drop vanilla restano nel mondo; l'equipaggiamento dei combattenti non viene lasciato a terra.
- Nessuna interazione combattiva con spettatori e mob esterni: i danni dell'arena sono ammessi soltanto fra fazioni opposte della sessione. I danni ambientali ai combattenti vengono ignorati; `/kill` e `reset` restano operativi.
- Il pathfinding resta quello di Minecraft. Usa campi piani e percorribili; muri chiusi e labirinti possono portare al pareggio per tempo scaduto.
- Le vittorie dipendono dalla simulazione. La gestione della vittoria Pillager è implementata, ma il risultato non è imposto.
- Le temporizzazioni sono espresse in tick: un server sotto 20 TPS rallenta anche battaglia e abilità.

## Riferimenti tecnici

- [Fabric per Minecraft 1.21 e 1.21.1](https://fabricmc.net/2024/05/31/121.html)
- [Documentazione Fabric Loom](https://docs.fabricmc.net/develop/loom/)
- [Attributi disponibili in Yarn 1.21.1](https://maven.fabricmc.net/docs/yarn-1.21.1+build.3/net/minecraft/entity/attribute/EntityAttributes.html)
- [ArrowEntity in Yarn 1.21.1](https://maven.fabricmc.net/docs/yarn-1.21.1+build.3/net/minecraft/entity/projectile/ArrowEntity.html)
- [Fabric GameTest API](https://github.com/FabricMC/fabric/tree/1.21.1/fabric-gametest-api-v1)
