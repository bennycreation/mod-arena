# Prova in gioco

Usa Minecraft 1.21.1 Fabric con un mondo di prova separato. Il client Minecraft 26.3 non può caricare questa mod.

## Scenario completo

1. Crea un mondo Creativa Superpiatto, con comandi attivi, difficoltà Normale.
2. In uno spazio aperto usa `/arena build` e `/arena start`.
3. Controlla che entrino sei Skeleton e sei Pillager, di cui uno più alto e con stendardo rosso.
4. Durante l'ingresso i mob non devono ferirsi. Dopo cinque secondi devono scegliere nemici e sparare.
5. Osserva fiancheggiamento, ritirate brevi e cambi di posizione presso le coperture.
6. Dopo trenta secondi, o metà perdite, verifica l'annuncio dell'assalto se la battaglia è ancora in corso.
7. Quando resta un solo Skeleton e subisce danni sufficienti, verifica l'attivazione di Ultimo Respiro: suono del totem, cura, luce, particelle e tiro più veloce.
8. Dopo dieci secondi, se è ancora vivo, verifica la fine dei potenziamenti e che non risorga una seconda volta.
9. Verifica il risultato e la pulizia automatica dopo otto secondi. `/arena status` conserva l'ultimo risultato.

La battaglia non è deterministica; non ogni prova mostrerà tutte le fasi. Il GameTest controlla separatamente i casi della resurrezione e degli esiti.

## Scenario breve per Ultimo Respiro

```mcfunction
/arena reset
/arena start 1 3
```

L'unico Skeleton è subito eleggibile; i tre Pillager ne mettono alla prova la resurrezione. `/kill` non attiva l'abilità e quindi non va usato per simulare il colpo letale.

## Robustezza

| Prova | Risultato atteso |
| --- | --- |
| `start` senza un centro | Messaggio che invita a usare `set` o `build`. |
| `start` due volte | Il secondo viene rifiutato, senza altri spawn. |
| `reset` durante ingresso, lotta o celebrazione | Rimozione immediata e limitata alla sessione. |
| `reset` due volte | Nessun errore. |
| `build` con un blocco nel volume | Rifiuto senza modifiche parziali. |
| `start` con ingresso ostruito | Rifiuto e rollback dei combattenti già creati. |
| Difficoltà Pacifica | Avvio rifiutato; una sessione attiva viene ripulita. |
| Un animale normale vicino al campo | Non deve essere eliminato dal reset o ferito dalle frecce dell'arena. |
| Un giocatore attraversa la linea di tiro | Non deve subire danni dai combattenti dell'arena. |
| Allontanarsi e tornare | I chunk della sessione restano trattenuti; la barra compare solo agli spettatori vicini. |
| Morte del comandante | Annuncio, perdita del coordinamento e cambiamento di movimento dei Pillager. |
| Riavvio del server | La sessione non riprende; le entità residue vengono eliminate al caricamento. |
| Arresto durante una battaglia | Squadre temporanee e risorse della sessione devono essere liberate. |

## Diagnosi

- **Java 8 / versione non supportata:** seleziona JDK 21 come Gradle JVM.
- **Minecraft incompatibile:** usa esattamente 1.21.1, con la versione corretta di Fabric API.
- **Comando sconosciuto:** controlla che il JAR della mod sia installato nel profilo o server attivo.
- **Nessuno si muove:** controlla la difficoltà, attendi la fine dell'ingresso e usa un campo piano con spazio libero.
- **AccessDeniedException durante Gradle:** verifica di avviare il progetto dal tuo IDE o terminale con accesso alla sua cartella. Nella preparazione automatica di questo progetto, il sandbox Windows ha impedito a Java di risolvere i percorsi in Documenti.
- **Rapporto di errore:** conserva `build/reports`, l'output Gradle e l'eventuale `logs/latest.log` della directory di test. Sono utili per individuare la fase che fallisce.
