package it.bonebanner.arena;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ArenaRulesTest {
    @Test void allVictoryAndDrawCasesAreDistinct() {
        assertNull(ArenaRules.outcome(2, 2));
        assertEquals(Phase.PILLAGER_VICTORY, ArenaRules.outcome(0, 1));
        assertEquals(Phase.SKELETON_VICTORY, ArenaRules.outcome(1, 0));
        assertEquals(Phase.DRAW, ArenaRules.outcome(0, 0));
    }
    @Test void lastBreathRequiresLastSkeletonAndCannotRenew() {
        LastBreath breath = new LastBreath();
        assertFalse(breath.activate(false, 1));
        assertFalse(breath.used());
        assertTrue(breath.activate(true, 100));
        assertTrue(breath.active(299));
        assertFalse(breath.active(300));
        assertFalse(breath.activate(true, 301));
        assertEquals(300, breath.expiresAt());
    }
    @Test void coverCanOutweighFinishingAWoundedTarget() {
        double hiddenWounded = ArenaRules.targetScore(10, .1, false, false, false, false, false, true);
        double visibleHealthy = ArenaRules.targetScore(10, 1, true, false, false, false, false, true);
        assertTrue(visibleHealthy > hiddenWounded);
    }
    @Test void defendingCommanderOutweighsASlightlyCloserEnemy() {
        double threat = ArenaRules.targetScore(12, .8, true, false, false, false, true, false);
        double closer = ArenaRules.targetScore(8, .8, true, false, false, false, false, false);
        assertTrue(threat > closer);
    }
    @Test void focusAndCurrentTargetReduceTargetThrashing() {
        double existing = ArenaRules.targetScore(12, 1, true, false, true, true, false, false);
        double alternative = ArenaRules.targetScore(8, 1, true, false, false, false, false, false);
        assertTrue(existing > alternative);
    }
}
