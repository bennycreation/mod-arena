package it.bonebanner.arena;

import it.bonebanner.ArenaMod;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.server.world.ChunkTicketType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Difficulty;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

/** Scenario unico e sequenziale: le sessioni condividono un solo ArenaManager per server. */
public class ArenaGameTests implements FabricGameTest {
    private static final ChunkTicketType<ChunkPos> TEST_TICKET = ChunkTicketType.create(
            "bonebanner_test_observer", Comparator.comparingLong(ChunkPos::toLong));
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 1600)
    public void lifecycleAndLethalRescue(TestContext context) {
        var world = context.getWorld();
        var server = world.getServer();
        server.setDifficulty(Difficulty.NORMAL, true);
        ArenaManager arena = ArenaMod.arena(server);
        arena.reset();
        var center = ArenaBuilder.build(world, context.getAbsolutePos(new BlockPos(30, 4, 30)), 16);
        arena.configure(world, center, 16);
        List<Fighter> oldFighters = new ArrayList<>();
        boolean[] naturalDamage = {false};
        PigEntity bystander = EntityType.PIG.create(world);
        context.assertTrue(bystander != null, "Il mob esterno deve essere creato");
        bystander.refreshPositionAndAngles(center.x, center.y, center.z + 10, 0, 0);
        bystander.setAiDisabled(true);
        bystander.setPersistent();
        world.spawnEntity(bystander);
        // La piattaforma è fuori dalla piccola struttura GameTest. Un ticket del test evita che
        // il maiale venga semplicemente scaricato quando reset rilascia i ticket dell'arena.
        ChunkPos observerChunk = new ChunkPos(bystander.getBlockPos());
        world.getChunkManager().addTicket(TEST_TICKET, observerChunk, 2, observerChunk);

        server.getCommandManager().executeWithPrefix(server.getCommandSource(), "arena start 3 3");
        context.assertTrue(arena.phase() == Phase.INTRO, "Il comando deve avviare l'ingresso");
        context.assertTrue(arena.fighters().size() == 6, "Devono entrare sei combattenti");
        context.assertTrue(arena.leader().mob.getAttributeValue(EntityAttributes.GENERIC_SCALE) == 1.45, "Il comandante deve essere ingrandito");
        context.assertTrue(arena.leader().mob.getMaxHealth() == 64, "Il comandante deve avere più vita");

        context.runAtTick(115, () -> {
            context.assertTrue(arena.combat(), "Dopo l'ingresso deve cominciare il combattimento");
            arena.selectTargets();
            for (Fighter fighter : arena.fighters()) {
                context.assertTrue(fighter.mob.getTarget() != null, "Ogni combattente deve selezionare un bersaglio");
                context.assertTrue(arena.fighter(fighter.mob.getTarget()).faction != fighter.faction, "Il bersaglio deve appartenere alla fazione avversaria");
                fighter.mob.setAiDisabled(true);
            }
            var skeletons = arena.living(Faction.SKELETON);
            var pillager = arena.leader().mob;
            var skeleton = skeletons.getFirst().mob;
            float initialHealth = skeleton.getHealth();
            skeleton.damage(world.getDamageSources().mobAttack(skeletons.get(1).mob), 5);
            context.assertTrue(skeleton.getHealth() == initialHealth, "Il fuoco amico deve essere ignorato");
            float pigHealth = bystander.getHealth();
            bystander.damage(world.getDamageSources().mobAttack(pillager), 8);
            context.assertTrue(bystander.getHealth() == pigHealth, "Il danno ai mob esterni deve essere ignorato");
            skeleton.timeUntilRegen = 0;
            skeleton.damage(world.getDamageSources().mobAttack(pillager), 1000);
            context.assertTrue(!skeleton.isAlive() && !skeletons.getFirst().breath.used(), "Uno scheletro non finale deve morire normalmente");
            skeletons.get(1).mob.discard();
            oldFighters.addAll(arena.fighters());
        });

        context.runAtTick(125, () -> {
            Fighter last = arena.living(Faction.SKELETON).getFirst();
            last.mob.timeUntilRegen = 0;
            last.mob.damage(world.getDamageSources().mobAttack(arena.leader().mob), 1000);
            context.assertTrue(last.alive(), "Ultimo Respiro deve annullare il colpo letale");
            context.assertTrue(last.mob.getHealth() > 0 && last.empowered(arena.elapsed()), "Il superstite deve essere curato e potenziato");
            context.assertTrue(arena.phase() == Phase.LAST_STAND, "Deve iniziare la fase finale");
        });

        context.runAtTick(335, () -> {
            Fighter last = arena.living(Faction.SKELETON).getFirst();
            context.assertTrue(!last.empowered(arena.elapsed()), "Il potenziamento deve scadere dopo 200 tick");
            last.mob.timeUntilRegen = 0;
            last.mob.damage(world.getDamageSources().mobAttack(arena.leader().mob), 1000);
            context.assertTrue(!last.alive(), "La resurrezione non deve essere ripetibile");
        });
        context.runAtTick(340, () -> context.assertTrue(arena.phase() == Phase.PILLAGER_VICTORY, "I Pillager devono ottenere la vittoria"));
        context.runAtTick(510, () -> {
            context.assertTrue(arena.phase() == Phase.IDLE && arena.fighters().isEmpty(), "La celebrazione deve terminare con la pulizia");
            context.assertTrue(oldFighters.stream().allMatch(f -> f.mob.isRemoved()), "Nessun combattente deve restare dopo il reset");
            context.assertTrue(bystander.isAlive(), "Il reset deve preservare i mob esterni");
            context.assertTrue(server.getScoreboard().getTeams().stream().noneMatch(t -> t.getName().startsWith("bba_")), "Le squadre temporanee devono essere rimosse");
            arena.start(1, 1);
            arena.fighters().forEach(f -> f.mob.setAiDisabled(true));
        });
        context.runAtTick(620, () -> arena.leader().mob.discard());
        context.runAtTick(625, () -> {
            context.assertTrue(arena.phase() == Phase.SKELETON_VICTORY, "Deve essere possibile anche la vittoria Skeleton");
            arena.reset();
            arena.reset();
            arena.start(1, 1);
            arena.fighters().forEach(f -> f.mob.setAiDisabled(true));
        });
        context.runAtTick(735, () -> arena.fighters().forEach(f -> f.mob.discard()));
        context.runAtTick(740, () -> {
            context.assertTrue(arena.phase() == Phase.DRAW, "Nessun superstite deve produrre un pareggio");
            arena.reset();
            // Entità residua di una sessione precedente: il caricamento deve eliminarla.
            var orphan = EntityType.SKELETON.create(world);
            orphan.refreshPositionAndAngles(bystander.getX(), bystander.getY(), bystander.getZ(), 0, 0);
            orphan.addCommandTag(ArenaManager.FIGHTER_TAG);
            world.spawnEntity(orphan);
            context.assertTrue(orphan.isRemoved(), "Un combattente orfano non deve restare nel mondo");
            arena.start(1, 1);
            ArrowEntity arrow = new ArrowEntity(world, arena.leader().mob, new ItemStack(Items.ARROW), new ItemStack(Items.CROSSBOW));
            arena.trackArrow(arrow);
            world.spawnEntity(arrow);
            server.getCommandManager().executeWithPrefix(server.getCommandSource(), "arena reset");
            context.assertTrue(arrow.isRemoved(), "Reset deve eliminare anche i proiettili");
            context.assertTrue(bystander.isAlive(), "Il mob esterno deve restare intatto");
            bystander.discard();
            // Ultima prova: lascia combattere davvero i goal, senza infliggere danno dal test.
            arena.start(2, 2);
        });
        for (int tick = 860; tick <= 1040; tick += 20) context.runAtTick(tick, () -> {
            if (arena.fighters().stream().anyMatch(f -> !f.alive() || f.mob.getHealth() < f.mob.getMaxHealth())) naturalDamage[0] = true;
        });
        context.runAtTick(1050, () -> {
            context.assertTrue(naturalDamage[0], "Navigazione e frecce reali devono produrre danno senza interventi del test");
            arena.reset();
            world.getChunkManager().removeTicket(TEST_TICKET, observerChunk, 2, observerChunk);
            context.complete();
        });
    }
}
