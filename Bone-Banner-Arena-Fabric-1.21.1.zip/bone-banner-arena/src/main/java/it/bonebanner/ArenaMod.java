package it.bonebanner;

import it.bonebanner.arena.ArenaManager;
import it.bonebanner.command.ArenaCommands;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.IdentityHashMap;
import java.util.Map;

public final class ArenaMod implements ModInitializer {
    public static final String ID = "bonebanner";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);
    private static final Map<MinecraftServer, ArenaManager> MANAGERS = new IdentityHashMap<>();

    public static ArenaManager arena(MinecraftServer server) {
        return MANAGERS.computeIfAbsent(server, ArenaManager::new);
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> ArenaCommands.register(dispatcher));
        ServerLifecycleEvents.SERVER_STARTED.register(server -> arena(server).cleanStaleTeams());
        ServerTickEvents.END_SERVER_TICK.register(server -> arena(server).tick());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            ArenaManager manager = MANAGERS.remove(server);
            if (manager != null) manager.reset();
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> arena(world.getServer()).onEntityLoad(entity));
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) ->
                entity.getServer() == null || arena(entity.getServer()).allowDamage(entity, source));
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) ->
                entity.getServer() == null || arena(entity.getServer()).allowDeath(entity, source));
        LOGGER.info("Bone & Banner Arena 1.0.0 - Minecraft 1.21.1");
    }
}
