package it.bonebanner.mixin;

import net.minecraft.entity.ai.goal.GoalSelector;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Consente di sostituire i goal SOLO ai combattenti creati dall'arena. */
@Mixin(MobEntity.class)
public interface MobEntityAccessor {
    @Accessor("goalSelector") GoalSelector bonebanner$getGoals();
    @Accessor("targetSelector") GoalSelector bonebanner$getTargets();
}
