package it.bonebanner.ai;

import it.bonebanner.arena.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/** Utility AI leggera: avanzata, tiro, fiancheggiamento e ritirata usano il pathfinding vanilla. */
public final class ArenaCombatGoal extends Goal {
    private final ArenaManager arena;
    private final Fighter fighter;
    private final MobEntity mob;
    private int cooldown;
    private int navigationClock;

    public ArenaCombatGoal(ArenaManager arena, Fighter fighter) {
        this.arena = arena;
        this.fighter = fighter;
        this.mob = fighter.mob;
        cooldown = 15 + mob.getRandom().nextInt(20);
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }
    @Override public boolean canStart() { return arena.combat() && fighter.alive(); }
    @Override public boolean shouldContinue() { return canStart(); }
    @Override public boolean shouldRunEveryTick() { return true; }
    @Override public void start() { mob.setAttacking(true); }
    @Override public void stop() {
        mob.setAttacking(false);
        mob.getNavigation().stop();
        mob.clearActiveItem();
        if (mob instanceof PillagerEntity pillager) pillager.setCharging(false);
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive()) { arena.selectTargets(); target = mob.getTarget(); }
        if (target == null) return;
        mob.getLookControl().lookAt(target, 30, 30);
        boolean visible = mob.canSee(target);
        double distance = mob.distanceTo(target);
        boolean empowered = fighter.empowered(arena.elapsed());
        if (--navigationClock <= 0) {
            navigate(target, visible, distance, empowered);
            navigationClock = 10;
        }
        if (cooldown > 0) cooldown--;
        if (mob instanceof PillagerEntity pillager) pillager.setCharging(cooldown > 0 && cooldown <= 16);
        else if (visible && cooldown < 18 && !mob.isUsingItem()) mob.setCurrentHand(Hand.MAIN_HAND);
        if (cooldown <= 0 && visible && distance <= 22) {
            // Un alleato davanti alla canna fa rimandare il tiro e incoraggia il riposizionamento.
            if (allyBlocksShot(target)) { cooldown = 6; navigationClock = 0; return; }
            shoot(target, empowered);
            int normal = fighter.faction == Faction.SKELETON ? 38 : fighter.leader ? 32 : 46;
            if (arena.phase() == Phase.ASSAULT) normal -= 8;
            cooldown = empowered ? 15 : Math.max(20, normal);
        }
    }

    private void navigate(LivingEntity target, boolean visible, double distance, boolean empowered) {
        Vec3d toward = target.getPos().subtract(mob.getPos()).multiply(1, 0, 1).normalize();
        double preferred = arena.phase() == Phase.SKIRMISH ? 10 : 6;
        if (fighter.faction == Faction.SKELETON) preferred += 2;
        if (empowered) preferred = 5;
        if (fighter.leader && mob.getHealth() < mob.getMaxHealth() * 0.4) preferred += 3;

        boolean wounded = mob.getHealth() < mob.getMaxHealth() * 0.3 && !empowered;
        if (wounded && fighter.retreatsUntil == 0) fighter.retreatsUntil = arena.elapsed() + 60;
        boolean retreat = (wounded && arena.elapsed() < fighter.retreatsUntil) || distance < preferred - 3;
        // Una ritirata per ferita dura al massimo tre secondi: non può bloccare la battaglia all'infinito.
        if (retreat && visible) {
            Vec3d point = mob.getPos().subtract(toward.multiply(3));
            if (arena.canStand(mob, point) && mob.getNavigation().startMovingTo(point.x, point.y, point.z, 1.15)) return;
        }
        if (!visible || distance > preferred + 2) {
            mob.getNavigation().startMovingTo(target, empowered ? 1.25 : 1.05);
        } else {
            // Le squadre aggirano in versi opposti. Dopo la morte del leader, i Pillager avanzano direttamente.
            double direction = fighter.squad == 0 ? 1 : -1;
            Vec3d lateral = new Vec3d(-toward.z, 0, toward.x).multiply(direction * 2.2);
            Vec3d point = mob.getPos().add(lateral).add(toward.multiply(0.4));
            if (fighter.faction == Faction.PILLAGER && arena.leader() == null) point = mob.getPos().add(toward.multiply(2));
            if (arena.canStand(mob, point)) mob.getNavigation().startMovingTo(point.x, point.y, point.z, 0.85);
            else mob.getNavigation().stop();
        }
        // Se una copertura blocca il pathfinder, prova il fianco opposto. Il limite di tempo gestisce arene impossibili.
        if (mob.squaredDistanceTo(fighter.lastPosition) < 0.04 && !visible) fighter.stuckTicks += 10;
        else fighter.stuckTicks = 0;
        fighter.lastPosition = mob.getPos();
        if (fighter.stuckTicks >= 40) {
            Vec3d alternate = mob.getPos().add(toward.z * 4, 0, -toward.x * 4);
            if (arena.canStand(mob, alternate)) mob.getNavigation().startMovingTo(alternate.x, alternate.y, alternate.z, 1.15);
            fighter.stuckTicks = 0;
        }
    }

    private boolean allyBlocksShot(LivingEntity target) {
        Vec3d from = mob.getEyePos();
        Vec3d to = target.getPos().add(0, target.getHeight() * 0.55, 0);
        return arena.living(fighter.faction).stream().anyMatch(ally -> ally != fighter
                && ally.mob.getBoundingBox().expand(0.15).raycast(from, to).isPresent());
    }

    private void shoot(LivingEntity target, boolean empowered) {
        ArrowEntity arrow = new ArrowEntity(arena.world(), mob, new ItemStack(Items.ARROW), mob.getMainHandStack().copy());
        double dx = target.getX() - mob.getX(), dz = target.getZ() - mob.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        // Compensazione dell'arco balistico, analoga a quella degli arcieri vanilla.
        double dy = target.getBodyY(0.45) - arrow.getY() + horizontal * 0.20;
        arrow.setVelocity(dx, dy, dz, 1.8f, empowered ? 1.0f : 4.0f);
        // Strength vanilla non aumenta il danno delle frecce: il bonus viene applicato al proiettile.
        arrow.setDamage(empowered ? 4.0 : fighter.leader ? 3.2 : fighter.faction == Faction.SKELETON ? 2.0 : 2.3);
        arrow.setCritical(empowered);
        arrow.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
        arena.trackArrow(arrow);
        arena.world().spawnEntity(arrow);
        mob.swingHand(Hand.MAIN_HAND);
        mob.clearActiveItem();
        mob.playSound(fighter.faction == Faction.SKELETON ? SoundEvents.ENTITY_SKELETON_SHOOT : SoundEvents.ITEM_CROSSBOW_SHOOT,
                0.8f, empowered ? 1.3f : 1);
    }
}
