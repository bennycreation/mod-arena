package it.bonebanner.arena;

public enum Phase {
    IDLE("Inattiva"), INTRO("Ingresso"), SKIRMISH("Schermaglia"),
    ASSAULT("Assalto"), LAST_STAND("Ultimo Respiro"),
    PILLAGER_VICTORY("Vittoria Pillager"), SKELETON_VICTORY("Vittoria Skeleton"), DRAW("Pareggio");

    public final String label;
    Phase(String label) { this.label = label; }
    public boolean isCombat() { return this == SKIRMISH || this == ASSAULT || this == LAST_STAND; }
    public boolean isFinished() { return this == PILLAGER_VICTORY || this == SKELETON_VICTORY || this == DRAW; }
}
