package it.bonebanner.arena;

public enum Faction {
    SKELETON, PILLAGER;

    public Faction enemy() { return this == SKELETON ? PILLAGER : SKELETON; }
}
