package it.bonebanner.arena;

/** Regole pure: verificabili senza avviare il motore Minecraft. */
public final class ArenaRules {
    public static final int INTRO_TICKS = 100;
    public static final int ASSAULT_TICKS = 600;
    public static final int MAX_COMBAT_TICKS = 20 * 180;
    public static final int CELEBRATION_TICKS = 160;
    public static final int BREATH_TICKS = 200;
    private ArenaRules() { }

    public static Phase outcome(int skeletons, int pillagers) {
        if (skeletons == 0 && pillagers == 0) return Phase.DRAW;
        if (skeletons == 0) return Phase.PILLAGER_VICTORY;
        if (pillagers == 0) return Phase.SKELETON_VICTORY;
        return null;
    }

    /** Un punteggio maggiore rende il bersaglio preferibile. */
    public static double targetScore(double distance, double healthRatio, boolean visible,
                                     boolean commander, boolean squadFocus, boolean current,
                                     boolean threatensLeader, boolean skeletonShooter) {
        return 60 - distance * 2 + (1 - healthRatio) * 18
                + (visible ? 16 : -24) + (current ? 9 : 0)
                + (squadFocus ? 14 : 0) + (threatensLeader ? 20 : 0)
                + (skeletonShooter && commander ? 12 : 0);
    }
}
