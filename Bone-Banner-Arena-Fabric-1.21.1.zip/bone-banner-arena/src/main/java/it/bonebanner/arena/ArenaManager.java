package it.bonebanner.arena;

import it.bonebanner.ArenaMod;
import it.bonebanner.ai.ArenaCombatGoal;
import it.bonebanner.mixin.MobEntityAccessor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ChunkTicketType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;

import java.util.*;

/** Una sessione per server. Tutte le mutazioni avvengono sul thread del server. */
public final class ArenaManager {
    public static final String FIGHTER_TAG = "bonebanner.fighter";
    public static final String ARROW_TAG = "bonebanner.arrow";
    private static final ChunkTicketType<ChunkPos> TICKET = ChunkTicketType.create(
            "bonebanner_arena", Comparator.comparingLong(ChunkPos::toLong));
    private final MinecraftServer server;
    private final Map<UUID, Fighter> fighters = new LinkedHashMap<>();
    private final Map<UUID, ArrowEntity> arrows = new HashMap<>();
    private final Map<Faction, Team> teams = new EnumMap<>(Faction.class);
    private final Set<ChunkPos> tickets = new HashSet<>();
    private final Set<UUID> greeted = new HashSet<>();
    private final ServerBossBar bar = new ServerBossBar(Text.literal("Bone & Banner"),
            BossBar.Color.RED, BossBar.Style.PROGRESS);
    private ServerWorld world;
    private Vec3d center;
    private int radius = 20;
    private int elapsed;
    private int phaseAge;
    private int combatAge;
    private int initialCount;
    private boolean leaderDeathAnnounced;
    private Phase phase = Phase.IDLE;
    private Phase lastResult = Phase.IDLE;

    public ArenaManager(MinecraftServer server) { this.server = server; }
    public Phase phase() { return phase; }
    public Phase lastResult() { return lastResult; }
    public ServerWorld world() { return world; }
    public Vec3d center() { return center; }
    public int radius() { return radius; }
    public int elapsed() { return elapsed; }
    public boolean configured() { return world != null && center != null; }
    public boolean running() { return phase != Phase.IDLE; }
    public boolean combat() { return phase.isCombat(); }
    public List<Fighter> fighters() { return List.copyOf(fighters.values()); }
    public Fighter fighter(Entity entity) { return entity == null ? null : fighters.get(entity.getUuid()); }
    public List<Fighter> living(Faction faction) {
        return fighters.values().stream().filter(f -> f.faction == faction && f.alive()).toList();
    }
    public Fighter leader() {
        return fighters.values().stream().filter(f -> f.leader && f.alive()).findFirst().orElse(null);
    }

    public void configure(ServerWorld newWorld, Vec3d newCenter, int newRadius) {
        if (running()) throw new IllegalStateException("Usa /arena reset prima di spostare l'arena.");
        if (newRadius < 16 || newRadius > 48) throw new IllegalArgumentException("Raggio ammesso: 16–48.");
        world = newWorld;
        center = new Vec3d(Math.floor(newCenter.x) + 0.5, Math.floor(newCenter.y), Math.floor(newCenter.z) + 0.5);
        radius = newRadius;
    }

    public void start(int skeletons, int pillagers) {
        if (!configured()) throw new IllegalStateException("Configura prima il centro con /arena set o /arena build.");
        if (running()) throw new IllegalStateException("Arena già avviata. Usa /arena reset.");
        if (skeletons < 1 || skeletons > 12 || pillagers < 1 || pillagers > 12)
            throw new IllegalArgumentException("Ogni fazione deve avere da 1 a 12 combattenti.");
        if (world.getDifficulty() == Difficulty.PEACEFUL)
            throw new IllegalStateException("I mob ostili scompaiono in Pacifica: scegli Facile, Normale o Difficile.");
        if (!world.getWorldBorder().contains(new Box(center.x - radius, center.y, center.z - radius,
                center.x + radius + 1, center.y + 4, center.z + radius + 1)))
            throw new IllegalStateException("L'arena oltrepassa il confine del mondo.");
        elapsed = phaseAge = combatAge = 0;
        initialCount = skeletons + pillagers;
        leaderDeathAnnounced = false;
        lastResult = Phase.IDLE;
        greeted.clear();
        phase = Phase.INTRO;
        try {
            retainChunks();
            createTeams();
            for (int i = 0; i < skeletons; i++) spawn(Faction.SKELETON, i, skeletons);
            for (int i = 0; i < pillagers; i++) spawn(Faction.PILLAGER, i, pillagers);
            updateAudience();
            announce("Le porte si aprono. Ossa contro stendardi!", Formatting.GOLD);
            sound(SoundEvents.BLOCK_BELL_USE, 1.2f, 0.7f);
            updateBar();
        } catch (RuntimeException error) {
            reset();
            throw error;
        }
    }

    private void spawn(Faction faction, int index, int count) {
        boolean isLeader = faction == Faction.PILLAGER && index == 0;
        MobEntity mob = faction == Faction.SKELETON ? EntityType.SKELETON.create(world) : EntityType.PILLAGER.create(world);
        if (mob == null) throw new IllegalStateException("Impossibile creare un combattente.");
        double side = faction == Faction.SKELETON ? -1 : 1;
        Vec3d point = center.add(side * radius * 0.55, 0, (index - (count - 1) / 2.0) * 1.8);
        mob.refreshPositionAndAngles(point.x, point.y, point.z, side < 0 ? -90 : 90, 0);
        mob.setPersistent();
        mob.setCanPickUpLoot(false);
        mob.addCommandTag(FIGHTER_TAG);
        mob.addCommandTag(faction == Faction.SKELETON ? "bonebanner.skeleton" : "bonebanner.pillager");
        mob.setCustomName(Text.literal(isLeader ? "Comandante Ferronero" :
                (faction == Faction.SKELETON ? "Skeleton " : "Pillager ") + (index + 1) + " · Squadra " + (index % 2 + 1))
                .formatted(faction == Faction.SKELETON ? Formatting.AQUA : Formatting.RED));
        mob.setCustomNameVisible(true);
        setAttribute(mob, EntityAttributes.GENERIC_MAX_HEALTH, isLeader ? 64 : faction == Faction.SKELETON ? 28 : 32);
        setAttribute(mob, EntityAttributes.GENERIC_MOVEMENT_SPEED, isLeader ? 0.30 : 0.27);
        setAttribute(mob, EntityAttributes.GENERIC_FOLLOW_RANGE, radius * 3);
        if (isLeader) {
            setAttribute(mob, EntityAttributes.GENERIC_SCALE, 1.45);
            setAttribute(mob, EntityAttributes.GENERIC_ARMOR, 6);
            setAttribute(mob, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.6);
            mob.addCommandTag("bonebanner.leader");
        }
        mob.setHealth(mob.getMaxHealth());
        mob.equipStack(EquipmentSlot.MAINHAND, new ItemStack(faction == Faction.SKELETON ? Items.BOW : Items.CROSSBOW));
        mob.equipStack(EquipmentSlot.HEAD, new ItemStack(isLeader ? Items.RED_BANNER : Items.IRON_HELMET));
        for (EquipmentSlot slot : EquipmentSlot.values()) mob.setEquipmentDropChance(slot, 0);
        if (mob instanceof PillagerEntity pillager) {
            pillager.setPatrolLeader(false);
            pillager.setAbleToJoinRaid(false);
        }
        if (!world.isSpaceEmpty(mob) || !world.getBlockState(BlockPos.ofFloored(point).down()).isSolidBlock(world, BlockPos.ofFloored(point).down()))
            throw new IllegalStateException("Punto di ingresso ostruito o senza pavimento: " + BlockPos.ofFloored(point).toShortString()
                    + ". Prepara un campo piano con /arena build.");
        Fighter fighter = new Fighter(mob, faction, index % 2, isLeader, point);
        MobEntityAccessor access = (MobEntityAccessor) mob;
        access.bonebanner$getGoals().clear(goal -> true);
        access.bonebanner$getTargets().clear(goal -> true);
        access.bonebanner$getGoals().add(0, new SwimGoal(mob));
        access.bonebanner$getGoals().add(1, new ArenaCombatGoal(this, fighter));
        // Registra prima dello spawn: ENTITY_LOAD deve riconoscere le entità della sessione.
        fighters.put(mob.getUuid(), fighter);
        server.getScoreboard().addScoreHolderToTeam(mob.getUuidAsString(), teams.get(faction));
        if (!world.spawnEntity(mob)) throw new IllegalStateException("Spawn del combattente rifiutato.");
        world.spawnParticles(ParticleTypes.POOF, point.x, point.y + 1, point.z, 20, 0.4, 0.8, 0.4, 0.03);
    }

    private static void setAttribute(MobEntity mob, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> type, double value) {
        var attribute = mob.getAttributeInstance(type);
        if (attribute != null) attribute.setBaseValue(value);
    }

    public void tick() {
        if (!running()) return;
        elapsed++;
        phaseAge++;
        if (world.getDifficulty() == Difficulty.PEACEFUL) {
            announce("Arena interrotta: difficoltà Pacifica.", Formatting.YELLOW);
            reset();
            return;
        }
        maintainFighters();
        arrows.values().removeIf(arrow -> {
            if (arrow.isRemoved()) return true;
            if (arrow.age > 100 || !inside(arrow.getPos(), radius + 3)) { arrow.discard(); return true; }
            return false;
        });
        if (elapsed % 20 == 0) { updateAudience(); updateBar(); }
        if (phase == Phase.INTRO) {
            if (phaseAge == 30) announce("Ferronero: «Due squadre. Proteggete i fianchi!»", Formatting.RED);
            if (phaseAge == 65) announce("Skeleton: «Le ossa ricordano ogni battaglia.»", Formatting.AQUA);
            if (phaseAge >= ArenaRules.INTRO_TICKS) {
                changePhase(Phase.SKIRMISH);
                announce("Combattete!", Formatting.GOLD);
                sound(SoundEvents.EVENT_RAID_HORN.value(), 1.2f, 1);
            }
            return;
        }
        if (phase.isFinished()) {
            if (phase == Phase.PILLAGER_VICTORY && phaseAge % 20 == 0) {
                for (Fighter fighter : living(Faction.PILLAGER)) {
                    fighter.mob.getJumpControl().setActive();
                    world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, fighter.mob.getX(), fighter.mob.getY() + 2,
                            fighter.mob.getZ(), 5, 0.4, 0.4, 0.4, 0.02);
                }
            }
            if (phaseAge >= ArenaRules.CELEBRATION_TICKS) reset();
            return;
        }
        combatAge++;
        int skeletons = living(Faction.SKELETON).size();
        int pillagers = living(Faction.PILLAGER).size();
        Phase outcome = ArenaRules.outcome(skeletons, pillagers);
        if (outcome != null) { finish(outcome); return; }
        if (combatAge >= ArenaRules.MAX_COMBAT_TICKS) { finish(Phase.DRAW); return; }
        if (leader() == null && !leaderDeathAnnounced) {
            leaderDeathAnnounced = true;
            announce("Il comandante è caduto! I Pillager rompono la formazione.", Formatting.YELLOW);
            living(Faction.PILLAGER).forEach(f -> f.mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 120, 0)));
        }
        if (phase == Phase.SKIRMISH && (combatAge >= ArenaRules.ASSAULT_TICKS || skeletons + pillagers <= initialCount / 2)) {
            changePhase(Phase.ASSAULT);
            announce("Assalto! Le squadre stringono il cerchio.", Formatting.GOLD);
            sound(SoundEvents.ENTITY_RAVAGER_ROAR, 0.7f, 1.2f);
        }
        if (skeletons == 1) {
            Fighter last = living(Faction.SKELETON).getFirst();
            if (last.mob.getHealth() <= last.mob.getMaxHealth() * 0.25f) activateBreath(last);
        }
        if (elapsed % 10 == 0) selectTargets();
        if (elapsed % 120 == 0 && leader() != null) rally();
    }

    private void maintainFighters() {
        for (Fighter fighter : fighters.values()) {
            if (!fighter.alive()) continue;
            MobEntity mob = fighter.mob;
            mob.extinguish();
            if (mob.getWorld() != world) { mob.discard(); continue; }
            if (!inside(mob.getPos(), radius - 1) || mob.getY() < center.y - 3 || mob.getY() > center.y + 8) {
                // I punti di ingresso sono verificati all'avvio e restano all'interno dei chunk trattenuti.
                mob.requestTeleport(fighter.spawn.x, fighter.spawn.y, fighter.spawn.z);
                mob.getNavigation().stop();
                mob.fallDistance = 0;
            }
            if (fighter.empowered(elapsed)) {
                // Regeneration vanilla non cura i non morti: la cura è intenzionalmente esplicita.
                if (elapsed % 20 == 0) mob.heal(1.5f);
                if (elapsed % 4 == 0) world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME,
                        mob.getX(), mob.getY() + 1, mob.getZ(), 3, 0.3, 0.6, 0.3, 0.015);
            } else if (fighter.breath.used() && !fighter.breathEndAnnounced) {
                fighter.breathEndAnnounced = true;
                announce("Ultimo Respiro si esaurisce. Lo scheletro torna vulnerabile.", Formatting.GRAY);
            }
        }
    }

    public void selectTargets() {
        Fighter commander = leader();
        Map<String, UUID> focus = new HashMap<>();
        // Gli stessi compagni rivalutano ogni mezzo secondo; un bonus evita cambi continui di bersaglio.
        for (Fighter shooter : fighters.values()) {
            if (!shooter.alive()) continue;
            String key = shooter.faction + ":" + shooter.squad;
            UUID focusId = focus.get(key);
            Fighter best = null;
            double bestScore = -Double.MAX_VALUE;
            for (Fighter candidate : living(shooter.faction.enemy())) {
                boolean threatensLeader = commander != null && shooter.faction == Faction.PILLAGER
                        && (candidate.mob.getTarget() == commander.mob || candidate.mob.squaredDistanceTo(commander.mob) < 36);
                double score = ArenaRules.targetScore(shooter.mob.distanceTo(candidate.mob),
                        candidate.mob.getHealth() / candidate.mob.getMaxHealth(), shooter.mob.canSee(candidate.mob),
                        candidate.leader, candidate.mob.getUuid().equals(focusId), shooter.mob.getTarget() == candidate.mob,
                        threatensLeader, shooter.faction == Faction.SKELETON);
                if (score > bestScore) { bestScore = score; best = candidate; }
            }
            shooter.mob.setTarget(best == null ? null : best.mob);
            if (best != null && (shooter.faction == Faction.SKELETON || commander != null)) focus.putIfAbsent(key, best.mob.getUuid());
        }
    }

    private void rally() {
        Fighter commander = leader();
        if (commander == null) return;
        living(Faction.PILLAGER).stream().filter(f -> f.mob.squaredDistanceTo(commander.mob) < 100)
                .forEach(f -> f.mob.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 50, 0)));
        world.spawnParticles(ParticleTypes.CRIT, commander.mob.getX(), commander.mob.getY() + 2, commander.mob.getZ(), 14, 1.5, 0.7, 1.5, 0.05);
        if (elapsed % 240 == 0) announce("Ferronero: «Coprite i feriti! Fuoco sul bersaglio!»", Formatting.RED);
    }

    private boolean activateBreath(Fighter fighter) {
        boolean alone = fighters.values().stream().noneMatch(other -> other != fighter && other.faction == Faction.SKELETON && other.alive());
        if (!combat() || fighter.faction != Faction.SKELETON || !fighter.breath.activate(alone, elapsed)) return false;
        fighter.mob.setHealth(fighter.mob.getMaxHealth() * 0.85f);
        fighter.mob.timeUntilRegen = 20;
        fighter.mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, ArenaRules.BREATH_TICKS, 1));
        fighter.mob.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, ArenaRules.BREATH_TICKS, 1));
        fighter.mob.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, ArenaRules.BREATH_TICKS, 0));
        changePhase(Phase.LAST_STAND);
        announce("ULTIMO RESPIRO — «Non è ancora la mia fine!»", Formatting.AQUA);
        sound(SoundEvents.ITEM_TOTEM_USE, 1, 0.8f);
        world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, fighter.mob.getX(), fighter.mob.getY() + 1,
                fighter.mob.getZ(), 100, 0.8, 1, 0.8, 0.3);
        return true;
    }

    /** Intercetta anche un colpo letale tra due tick: non si affida solo alla soglia di vita. */
    public boolean allowDeath(LivingEntity entity, DamageSource source) {
        Fighter fighter = fighter(entity);
        if (fighter == null || source.isOf(DamageTypes.GENERIC_KILL)) return true;
        return !activateBreath(fighter);
    }

    public boolean allowDamage(LivingEntity victim, DamageSource source) {
        Fighter target = fighter(victim);
        Fighter attacker = fighter(source.getAttacker());
        boolean arenaArrow = source.getSource() != null && source.getSource().getCommandTags().contains(ARROW_TAG);
        if (target == null && attacker == null && !arenaArrow) return true;
        if (target != null && source.isOf(DamageTypes.GENERIC_KILL)) return true;
        // I colpi dell'arena non colpiscono spettatori, animali o mob esterni, anche dopo la morte del tiratore.
        if (target == null || attacker == null || !combat()) return false;
        return attacker.faction != target.faction;
    }

    public void trackArrow(ArrowEntity arrow) {
        arrow.addCommandTag(ARROW_TAG);
        arrows.put(arrow.getUuid(), arrow);
    }

    public void onEntityLoad(Entity entity) {
        // Dopo il riavvio non si riprende una battaglia: si eliminano solo le nostre entità orfane.
        if (entity.getCommandTags().contains(FIGHTER_TAG) && !fighters.containsKey(entity.getUuid())) entity.discard();
        if (entity.getCommandTags().contains(ARROW_TAG) && !arrows.containsKey(entity.getUuid())) entity.discard();
    }

    private void finish(Phase outcome) {
        lastResult = outcome;
        changePhase(outcome);
        fighters.values().forEach(f -> { f.mob.setTarget(null); f.mob.getNavigation().stop(); });
        arrows.values().forEach(Entity::discard);
        arrows.clear();
        if (outcome == Phase.PILLAGER_VICTORY) {
            announce("VITTORIA PILLAGER! «L'arena appartiene agli stendardi!»", Formatting.RED);
            sound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1, 0.8f);
            living(Faction.PILLAGER).forEach(f -> f.mob.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, ArenaRules.CELEBRATION_TICKS, 0)));
        } else if (outcome == Phase.SKELETON_VICTORY) {
            announce("VITTORIA SKELETON! Le ossa resistono.", Formatting.AQUA);
            sound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1, 1.2f);
        } else {
            announce("PAREGGIO — tempo scaduto o nessun superstite.", Formatting.YELLOW);
            sound(SoundEvents.BLOCK_BELL_USE, 1, 0.6f);
        }
        updateBar();
    }

    private void changePhase(Phase next) { phase = next; phaseAge = 0; updateBar(); }

    public boolean inside(Vec3d point, double range) {
        return center != null && Math.abs(point.x - center.x) <= range && Math.abs(point.z - center.z) <= range;
    }

    /** Verifica destinazioni laterali/ritirata senza far entrare l'AI nei muri o nel vuoto. */
    public boolean canStand(MobEntity mob, Vec3d point) {
        BlockPos floor = BlockPos.ofFloored(point).down();
        return inside(point, radius - 2) && world.getBlockState(floor).isSolidBlock(world, floor)
                && world.isSpaceEmpty(mob, mob.getBoundingBox().offset(point.subtract(mob.getPos())));
    }

    private boolean isAudience(ServerPlayerEntity player) {
        return player.getServerWorld() == world && inside(player.getPos(), radius + 32) && Math.abs(player.getY() - center.y) < 40;
    }
    private void updateAudience() {
        for (ServerPlayerEntity old : List.copyOf(bar.getPlayers())) if (!isAudience(old) || old.isDisconnected()) bar.removePlayer(old);
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (!isAudience(player)) continue;
            bar.addPlayer(player);
            if (greeted.add(player.getUuid())) player.sendMessage(Text.literal("[Arena] Benvenuto sugli spalti. La battaglia è automatica!").formatted(Formatting.GOLD), false);
        }
    }
    private void updateBar() {
        int skeletons = living(Faction.SKELETON).size(), pillagers = living(Faction.PILLAGER).size();
        bar.setName(Text.literal(phase.label + " | Skeleton " + skeletons + " : " + pillagers + " Pillager"));
        bar.setPercent(initialCount == 0 ? 0 : Math.min(1, (skeletons + pillagers) / (float) initialCount));
        bar.setColor(phase == Phase.LAST_STAND || phase == Phase.SKELETON_VICTORY ? BossBar.Color.BLUE : BossBar.Color.RED);
    }
    public void announce(String message, Formatting color) {
        ArenaMod.LOGGER.info("[Arena] {}", message);
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) if (isAudience(player))
            player.sendMessage(Text.literal("[Arena] " + message).formatted(color), false);
    }
    private void sound(SoundEvent event, float volume, float pitch) {
        world.playSound(null, center.x, center.y + 1, center.z, event, SoundCategory.HOSTILE, volume, pitch);
    }

    private void createTeams() {
        String suffix = UUID.randomUUID().toString().substring(0, 6);
        for (Faction faction : Faction.values()) {
            Team team = server.getScoreboard().addTeam("bba_" + (faction == Faction.SKELETON ? "s_" : "p_") + suffix);
            team.setColor(faction == Faction.SKELETON ? Formatting.AQUA : Formatting.RED);
            team.setFriendlyFireAllowed(false);
            team.setCollisionRule(AbstractTeam.CollisionRule.NEVER);
            teams.put(faction, team);
        }
    }
    public void cleanStaleTeams() {
        for (Team team : List.copyOf(server.getScoreboard().getTeams()))
            if (team.getName().matches("bba_[sp]_[0-9a-f]{6}")) server.getScoreboard().removeTeam(team);
    }
    private void retainChunks() {
        for (int x = (int) Math.floor((center.x - radius) / 16); x <= (int) Math.floor((center.x + radius) / 16); x++)
            for (int z = (int) Math.floor((center.z - radius) / 16); z <= (int) Math.floor((center.z + radius) / 16); z++) {
                ChunkPos chunk = new ChunkPos(x, z);
                world.getChunkManager().addTicket(TICKET, chunk, 2, chunk);
                world.getChunk(x, z);
                tickets.add(chunk);
            }
    }

    /** Reset idempotente: non usa selettori globali e non modifica le squadre dei giocatori. */
    public void reset() {
        phase = Phase.IDLE;
        for (ArrowEntity arrow : arrows.values()) arrow.discard();
        arrows.clear();
        for (Fighter fighter : fighters.values()) {
            fighter.mob.getNavigation().stop();
            fighter.mob.setTarget(null);
            fighter.mob.discard();
        }
        fighters.clear();
        for (Team team : teams.values()) server.getScoreboard().removeTeam(team);
        teams.clear();
        if (world != null) for (ChunkPos chunk : tickets) world.getChunkManager().removeTicket(TICKET, chunk, 2, chunk);
        tickets.clear();
        greeted.clear();
        bar.clearPlayers();
    }

    public String status() {
        return phase.label + " | Skeleton: " + living(Faction.SKELETON).size() + " | Pillager: " + living(Faction.PILLAGER).size()
                + " | Ultimo risultato: " + lastResult.label
                + (configured() ? " | Centro: " + BlockPos.ofFloored(center).toShortString() + " | Raggio: " + radius : " | Centro non configurato");
    }
}
