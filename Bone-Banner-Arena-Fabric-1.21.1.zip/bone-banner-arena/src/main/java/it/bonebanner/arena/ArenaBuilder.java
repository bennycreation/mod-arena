package it.bonebanner.arena;

import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Costruisce una piattaforma sopra il giocatore soltanto se l'intero volume è libero. */
public final class ArenaBuilder {
    private ArenaBuilder() { }

    public static Vec3d build(ServerWorld world, BlockPos player, int radius) {
        BlockPos floorCenter = player.up(4);
        if (floorCenter.getY() + 5 >= world.getTopY()) throw new IllegalStateException("Spazio insufficiente sotto il limite del mondo.");
        // Prima si valida tutto: un errore non lascia una piattaforma parziale.
        for (BlockPos pos : BlockPos.iterate(floorCenter.add(-radius, 0, -radius), floorCenter.add(radius, 5, radius))) {
            if (!world.getWorldBorder().contains(pos) || !world.getBlockState(pos).isAir())
                throw new IllegalStateException("Volume occupato a " + pos.toShortString() + ". Spostati in uno spazio aperto; nessun blocco è stato sostituito.");
        }
        for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
            BlockPos base = floorCenter.add(x, 0, z);
            boolean edge = Math.abs(x) == radius || Math.abs(z) == radius;
            world.setBlockState(base, (x < 0 ? Blocks.SMOOTH_STONE : Blocks.POLISHED_DEEPSLATE).getDefaultState());
            if (edge) for (int y = 1; y <= 3; y++) world.setBlockState(base.up(y), Blocks.GLASS.getDefaultState());
            if (x == 0) world.setBlockState(base, Blocks.CHISELED_STONE_BRICKS.getDefaultState());
            if (Math.abs(x) == radius - 1 && z % 5 == 0) world.setBlockState(base, Blocks.SEA_LANTERN.getDefaultState());
        }
        // Piccole coperture laterali, con corridoi larghi per il comandante ingrandito.
        for (int x : new int[]{-4, 4}) for (int z : new int[]{-6, 6})
            for (int y = 1; y <= 2; y++) world.setBlockState(floorCenter.add(x, y, z), Blocks.STONE_BRICKS.getDefaultState());
        return Vec3d.ofBottomCenter(floorCenter.up());
    }
}
