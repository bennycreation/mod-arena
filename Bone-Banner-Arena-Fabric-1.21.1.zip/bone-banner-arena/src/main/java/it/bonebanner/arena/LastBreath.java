package it.bonebanner.arena;

/** Una sola attivazione; il tempo viene misurato in tick del server, non dell'orologio. */
public final class LastBreath {
    private boolean used;
    private long expiresAt;

    public boolean activate(boolean lastSkeleton, long tick) {
        if (!lastSkeleton || used) return false;
        used = true;
        expiresAt = tick + ArenaRules.BREATH_TICKS;
        return true;
    }
    public boolean active(long tick) { return used && tick < expiresAt; }
    public boolean used() { return used; }
    public long expiresAt() { return expiresAt; }
}
