package it.bonebanner.arena;

import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.math.Vec3d;

/** Stato individuale: il mob mantiene navigazione, fisica e animazioni vanilla. */
public final class Fighter {
    public final MobEntity mob;
    public final Faction faction;
    public final int squad;
    public final boolean leader;
    public final Vec3d spawn;
    public final LastBreath breath = new LastBreath();
    public boolean breathEndAnnounced;
    public Vec3d lastPosition;
    public int stuckTicks;
    public int retreatsUntil;

    public Fighter(MobEntity mob, Faction faction, int squad, boolean leader, Vec3d spawn) {
        this.mob = mob;
        this.faction = faction;
        this.squad = squad;
        this.leader = leader;
        this.spawn = spawn;
        this.lastPosition = spawn;
    }
    public boolean alive() { return mob.isAlive() && !mob.isRemoved(); }
    public boolean empowered(long tick) { return breath.active(tick); }
}
