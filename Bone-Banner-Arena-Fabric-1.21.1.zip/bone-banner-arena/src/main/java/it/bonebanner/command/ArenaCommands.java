package it.bonebanner.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import it.bonebanner.ArenaMod;
import it.bonebanner.arena.ArenaBuilder;
import it.bonebanner.arena.ArenaManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class ArenaCommands {
    private ArenaCommands() { }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("arena").requires(source -> source.hasPermissionLevel(2))
                .executes(ArenaCommands::help)
                .then(literal("help").executes(ArenaCommands::help))
                .then(literal("set").executes(ctx -> configure(ctx, 20))
                        .then(argument("raggio", IntegerArgumentType.integer(16, 48))
                                .executes(ctx -> configure(ctx, IntegerArgumentType.getInteger(ctx, "raggio")))))
                .then(literal("build").executes(ctx -> build(ctx, 20))
                        .then(argument("raggio", IntegerArgumentType.integer(16, 48))
                                .executes(ctx -> build(ctx, IntegerArgumentType.getInteger(ctx, "raggio")))))
                .then(literal("start").executes(ctx -> start(ctx, 6, 6))
                        .then(argument("skeleton", IntegerArgumentType.integer(1, 12))
                                .then(argument("pillager", IntegerArgumentType.integer(1, 12))
                                        .executes(ctx -> start(ctx, IntegerArgumentType.getInteger(ctx, "skeleton"),
                                                IntegerArgumentType.getInteger(ctx, "pillager"))))))
                .then(literal("reset").executes(ctx -> {
                    arena(ctx).reset();
                    reply(ctx, "Arena ripulita. Centro e piattaforma conservati.");
                    return 1;
                }))
                .then(literal("status").executes(ctx -> { reply(ctx, arena(ctx).status()); return 1; })));
    }
    private static ArenaManager arena(CommandContext<ServerCommandSource> ctx) { return ArenaMod.arena(ctx.getSource().getServer()); }

    private static int configure(CommandContext<ServerCommandSource> ctx, int radius) {
        return guarded(ctx, () -> {
            var player = ctx.getSource().getPlayerOrThrow();
            arena(ctx).configure(player.getServerWorld(), player.getPos(), radius);
            reply(ctx, "Centro impostato. Raggio " + radius + ". Avvia con /arena start.");
        });
    }
    private static int build(CommandContext<ServerCommandSource> ctx, int radius) {
        return guarded(ctx, () -> {
            var manager = arena(ctx);
            if (manager.running()) throw new IllegalStateException("Usa /arena reset prima di costruire.");
            var player = ctx.getSource().getPlayerOrThrow();
            var center = ArenaBuilder.build(player.getServerWorld(), player.getBlockPos(), radius);
            manager.configure(player.getServerWorld(), center, radius);
            player.requestTeleport(center.x, center.y, center.z);
            reply(ctx, "Campo costruito: " + (radius * 2 + 1) + " × " + (radius * 2 + 1) + ". Usa /arena start.");
        });
    }
    private static int start(CommandContext<ServerCommandSource> ctx, int skeletons, int pillagers) {
        return guarded(ctx, () -> {
            arena(ctx).start(skeletons, pillagers);
            reply(ctx, "Ingresso avviato: " + skeletons + " Skeleton contro " + pillagers + " Pillager (comandante incluso).");
        });
    }
    private static int help(CommandContext<ServerCommandSource> ctx) {
        reply(ctx, "/arena build [raggio] — crea un campo sopra di te in uno spazio vuoto\n"
                + "/arena set [raggio] — usa il campo esistente, centrato sui tuoi piedi\n"
                + "/arena start [skeleton pillager] — default 6 contro 6\n"
                + "/arena status — fase, superstiti e risultato\n"
                + "/arena reset — rimuove combattenti, frecce e squadre dell'arena");
        return 1;
    }
    private static void reply(CommandContext<ServerCommandSource> ctx, String message) {
        ctx.getSource().sendFeedback(() -> Text.literal("[Arena] " + message).formatted(Formatting.GOLD), false);
    }
    @FunctionalInterface private interface Action { void run() throws Exception; }
    private static int guarded(CommandContext<ServerCommandSource> ctx, Action action) {
        try { action.run(); return 1; }
        catch (Exception error) {
            ctx.getSource().sendError(Text.literal(error.getMessage() == null ? "Operazione arena fallita." : error.getMessage()));
            if (!(error instanceof IllegalArgumentException || error instanceof IllegalStateException
                    || error instanceof com.mojang.brigadier.exceptions.CommandSyntaxException))
                ArenaMod.LOGGER.error("Errore nel comando arena", error);
            return 0;
        }
    }
}
