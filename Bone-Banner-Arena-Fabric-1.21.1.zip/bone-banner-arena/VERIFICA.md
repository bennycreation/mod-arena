# Verifiche eseguite

Data: **18 settembre 2026**.

## Risultato

**BUILD SUCCESSFUL** con Minecraft Java **1.21.1**, Fabric Loader **0.16.14**, Fabric API **0.116.6+1.21.1**, Loom **1.8.13**, Gradle **8.10.2** e JDK **21**.

Comando eseguito:

```text
gradlew.bat --no-daemon --console plain build runGametest
```

- **Compilazione dei sorgenti principali e di test: riuscita.**
- **JAR di produzione rimappato: generato.**
- **JUnit: 5 test, 0 errori, 0 fallimenti.**
- **GameTest: 1 scenario completo, superato.**
- **Contenuto del JAR:** verificati versione, dipendenze, configurazione Mixin e refmap; le classi di test non sono incluse.
- **Gradle Wrapper:** provenienza ufficiale e checksum verificati.

## Che cosa controlla il GameTest

Lo scenario eseguito nel server Minecraft verifica, in sequenza:

1. Avvio mediante comando, ingresso, conteggio dei combattenti, scala e salute del comandante.
2. Selezione dei bersagli appartenenti alla fazione nemica.
3. Rifiuto del fuoco amico e del danno a un mob esterno.
4. Morte normale di uno Skeleton quando non è l'ultimo.
5. Resurrezione dell'ultimo Skeleton dopo un colpo letale, recupero di salute e cambio di fase.
6. Scadenza del potenziamento dopo 200 tick e impossibilità di una seconda resurrezione.
7. Vittoria Pillager, celebrazione, pulizia automatica e conservazione del mob esterno.
8. Vittoria Skeleton e pareggio per eliminazione di entrambe le fazioni.
9. Reset ripetuto, rimozione delle frecce e delle entità orfane.
10. Battaglia autonoma 2 contro 2: navigazione e frecce reali producono danni senza che il test li infligga.

Il test trattiene separatamente il chunk del mob esterno: ciò distingue la sua conservazione dall'ordinario scaricamento dei chunk quando l'arena termina.

## Limiti della verifica

Il controllo in un client grafico, l'ascolto dei suoni, il bilanciamento su molte partite e la compatibilità con altre mod non sono stati verificati. La checklist per queste prove è in `TEST_MANUALI.md`.

La compilazione automatica iniziale ha incontrato una restrizione dei percorsi nel sandbox Windows. Il controllo completo è stato poi avviato dall'utente nel proprio account tramite `VERIFICA-MOD.cmd`, e il relativo log è stato letto e verificato. Questo limite non riguarda il codice distribuito.

Per ripetere i controlli su un altro computer bastano JDK 21 e il wrapper incluso. Il launcher `VERIFICA-MOD.cmd` fornito accanto al progetto usa invece il percorso del JDK portatile di questo specifico computer e non fa parte del progetto portabile.
